
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.Timer; 
import java.io.File;
import javax.sound.sampled.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Charles
 */
public class Normal extends javax.swing.JFrame {
    /**
     * Creates new form Normal
     */
private int isFirstClick = 1;
    JButton jButton[];
    Timer timer;
    int sec = 60;   
    int speed = 1000;
    public Normal() {
        initComponents();
         //<editor-fold defaultstate="collapsed" desc=" Icons ">
        b41.setIcon(null);
        b23.setIcon(null);
        b63.setIcon(null);
        b73.setIcon(null);
        b15.setIcon(null);
        b45.setIcon(null);
        b95.setIcon(null);
        b7.setIcon(null);
        b9.setIcon(null);
        b48.setIcon(null);
        b66.setIcon(null);
        b78.setIcon(null);
        b100.setIcon(null);
        
        
        b3.setIcon(null);
        b5.setIcon(null);
        b13.setIcon(null);
        b20.setIcon(null);
        b27.setIcon(null);
        b34.setIcon(null);
        b37.setIcon(null);
        b50.setIcon(null);
        b64.setIcon(null);
        b76.setIcon(null);
        b81.setIcon(null);
        b91.setIcon(null);
        b94.setIcon(null);
        b98.setIcon(null);
         //</editor-fold>
    timer = new Timer(speed,new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                 if (sec<12)
                            {
                                lTimer.setForeground(Color.red);
                            }
                 if (sec<13)
                           {
                     try
                        {
                         Clip clip = AudioSystem.getClip();
                         clip.open(AudioSystem.getAudioInputStream(new File("D:\\timer.wav")));
                         clip.start();
                         }
                        catch (Exception exc)
                        {
                            exc.printStackTrace(System.out);
                        }
                           }
    
                 
                 
                 
                if (sec<1)
                {
                    //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
                      timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Times Up!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
                      sec = 0;
                      timer.stop();
                }
                else
                {
                    sec--;
                    String str2 = Integer.toString(sec);
                    lTimer.setText(str2);
                }
                
            }
        });
        timer.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        b1 = new javax.swing.JButton();
        b11 = new javax.swing.JButton();
        b21 = new javax.swing.JButton();
        b31 = new javax.swing.JButton();
        b41 = new javax.swing.JButton();
        b51 = new javax.swing.JButton();
        b61 = new javax.swing.JButton();
        b71 = new javax.swing.JButton();
        b81 = new javax.swing.JButton();
        b91 = new javax.swing.JButton();
        b92 = new javax.swing.JButton();
        b82 = new javax.swing.JButton();
        b72 = new javax.swing.JButton();
        b62 = new javax.swing.JButton();
        b52 = new javax.swing.JButton();
        b42 = new javax.swing.JButton();
        b32 = new javax.swing.JButton();
        b22 = new javax.swing.JButton();
        b12 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b93 = new javax.swing.JButton();
        b83 = new javax.swing.JButton();
        b73 = new javax.swing.JButton();
        b63 = new javax.swing.JButton();
        b53 = new javax.swing.JButton();
        b43 = new javax.swing.JButton();
        b33 = new javax.swing.JButton();
        b23 = new javax.swing.JButton();
        b13 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b94 = new javax.swing.JButton();
        b84 = new javax.swing.JButton();
        b74 = new javax.swing.JButton();
        b64 = new javax.swing.JButton();
        b54 = new javax.swing.JButton();
        b44 = new javax.swing.JButton();
        b34 = new javax.swing.JButton();
        b24 = new javax.swing.JButton();
        b14 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b95 = new javax.swing.JButton();
        b85 = new javax.swing.JButton();
        b75 = new javax.swing.JButton();
        b65 = new javax.swing.JButton();
        b55 = new javax.swing.JButton();
        b45 = new javax.swing.JButton();
        b35 = new javax.swing.JButton();
        b25 = new javax.swing.JButton();
        b15 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b96 = new javax.swing.JButton();
        b86 = new javax.swing.JButton();
        b76 = new javax.swing.JButton();
        b66 = new javax.swing.JButton();
        b56 = new javax.swing.JButton();
        b46 = new javax.swing.JButton();
        b36 = new javax.swing.JButton();
        b26 = new javax.swing.JButton();
        b16 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b97 = new javax.swing.JButton();
        b87 = new javax.swing.JButton();
        b77 = new javax.swing.JButton();
        b67 = new javax.swing.JButton();
        b57 = new javax.swing.JButton();
        b47 = new javax.swing.JButton();
        b37 = new javax.swing.JButton();
        b27 = new javax.swing.JButton();
        b17 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b98 = new javax.swing.JButton();
        b88 = new javax.swing.JButton();
        b78 = new javax.swing.JButton();
        b68 = new javax.swing.JButton();
        b58 = new javax.swing.JButton();
        b48 = new javax.swing.JButton();
        b38 = new javax.swing.JButton();
        b28 = new javax.swing.JButton();
        b18 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b99 = new javax.swing.JButton();
        b89 = new javax.swing.JButton();
        b79 = new javax.swing.JButton();
        b69 = new javax.swing.JButton();
        b59 = new javax.swing.JButton();
        b49 = new javax.swing.JButton();
        b39 = new javax.swing.JButton();
        b29 = new javax.swing.JButton();
        b19 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        b100 = new javax.swing.JButton();
        b90 = new javax.swing.JButton();
        b80 = new javax.swing.JButton();
        b70 = new javax.swing.JButton();
        b60 = new javax.swing.JButton();
        b50 = new javax.swing.JButton();
        b40 = new javax.swing.JButton();
        b30 = new javax.swing.JButton();
        b20 = new javax.swing.JButton();
        b10 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lScore = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        lTimer = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MINESWEEPER");

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        b1.setBackground(new java.awt.Color(0, 255, 255));
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b11.setBackground(new java.awt.Color(0, 255, 255));
        b11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b11ActionPerformed(evt);
            }
        });

        b21.setBackground(new java.awt.Color(0, 255, 255));
        b21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b21ActionPerformed(evt);
            }
        });

        b31.setBackground(new java.awt.Color(0, 255, 255));
        b31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b31ActionPerformed(evt);
            }
        });

        b41.setBackground(new java.awt.Color(0, 255, 255));
        b41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b41ActionPerformed(evt);
            }
        });

        b51.setBackground(new java.awt.Color(0, 255, 255));
        b51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b51ActionPerformed(evt);
            }
        });

        b61.setBackground(new java.awt.Color(0, 255, 255));
        b61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b61ActionPerformed(evt);
            }
        });

        b71.setBackground(new java.awt.Color(0, 255, 255));
        b71.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b71ActionPerformed(evt);
            }
        });

        b81.setBackground(new java.awt.Color(0, 255, 255));
        b81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1.png"))); // NOI18N
        b81.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b81ActionPerformed(evt);
            }
        });

        b91.setBackground(new java.awt.Color(0, 255, 255));
        b91.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1.png"))); // NOI18N
        b91.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b91ActionPerformed(evt);
            }
        });

        b92.setBackground(new java.awt.Color(0, 255, 255));
        b92.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b92ActionPerformed(evt);
            }
        });

        b82.setBackground(new java.awt.Color(0, 255, 255));
        b82.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b82ActionPerformed(evt);
            }
        });

        b72.setBackground(new java.awt.Color(0, 255, 255));
        b72.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b72ActionPerformed(evt);
            }
        });

        b62.setBackground(new java.awt.Color(0, 255, 255));
        b62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b62ActionPerformed(evt);
            }
        });

        b52.setBackground(new java.awt.Color(0, 255, 255));
        b52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b52ActionPerformed(evt);
            }
        });

        b42.setBackground(new java.awt.Color(0, 255, 255));
        b42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b42ActionPerformed(evt);
            }
        });

        b32.setBackground(new java.awt.Color(0, 255, 255));
        b32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b32ActionPerformed(evt);
            }
        });

        b22.setBackground(new java.awt.Color(0, 255, 255));
        b22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b22ActionPerformed(evt);
            }
        });

        b12.setBackground(new java.awt.Color(0, 255, 255));
        b12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b12ActionPerformed(evt);
            }
        });

        b2.setBackground(new java.awt.Color(0, 255, 255));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b93.setBackground(new java.awt.Color(0, 255, 255));
        b93.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b93ActionPerformed(evt);
            }
        });

        b83.setBackground(new java.awt.Color(0, 255, 255));
        b83.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b83ActionPerformed(evt);
            }
        });

        b73.setBackground(new java.awt.Color(0, 255, 255));
        b73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b73ActionPerformed(evt);
            }
        });

        b63.setBackground(new java.awt.Color(0, 255, 255));
        b63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b63ActionPerformed(evt);
            }
        });

        b53.setBackground(new java.awt.Color(0, 255, 255));
        b53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b53ActionPerformed(evt);
            }
        });

        b43.setBackground(new java.awt.Color(0, 255, 255));
        b43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b43ActionPerformed(evt);
            }
        });

        b33.setBackground(new java.awt.Color(0, 255, 255));
        b33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b33ActionPerformed(evt);
            }
        });

        b23.setBackground(new java.awt.Color(0, 255, 255));
        b23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b23ActionPerformed(evt);
            }
        });

        b13.setBackground(new java.awt.Color(0, 255, 255));
        b13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/3.png"))); // NOI18N
        b13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b13ActionPerformed(evt);
            }
        });

        b3.setBackground(new java.awt.Color(0, 255, 255));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1.png"))); // NOI18N
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b94.setBackground(new java.awt.Color(0, 255, 255));
        b94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/6.png"))); // NOI18N
        b94.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b94ActionPerformed(evt);
            }
        });

        b84.setBackground(new java.awt.Color(0, 255, 255));
        b84.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b84ActionPerformed(evt);
            }
        });

        b74.setBackground(new java.awt.Color(0, 255, 255));
        b74.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b74ActionPerformed(evt);
            }
        });

        b64.setBackground(new java.awt.Color(0, 255, 255));
        b64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Minesweeper Numbers/9.png"))); // NOI18N
        b64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b64ActionPerformed(evt);
            }
        });

        b54.setBackground(new java.awt.Color(0, 255, 255));
        b54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b54ActionPerformed(evt);
            }
        });

        b44.setBackground(new java.awt.Color(0, 255, 255));
        b44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b44ActionPerformed(evt);
            }
        });

        b34.setBackground(new java.awt.Color(0, 255, 255));
        b34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/7.png"))); // NOI18N
        b34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b34ActionPerformed(evt);
            }
        });

        b24.setBackground(new java.awt.Color(0, 255, 255));
        b24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b24ActionPerformed(evt);
            }
        });

        b14.setBackground(new java.awt.Color(0, 255, 255));
        b14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b14ActionPerformed(evt);
            }
        });

        b4.setBackground(new java.awt.Color(0, 255, 255));
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b95.setBackground(new java.awt.Color(0, 255, 255));
        b95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b95.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b95ActionPerformed(evt);
            }
        });

        b85.setBackground(new java.awt.Color(0, 255, 255));
        b85.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b85ActionPerformed(evt);
            }
        });

        b75.setBackground(new java.awt.Color(0, 255, 255));
        b75.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b75ActionPerformed(evt);
            }
        });

        b65.setBackground(new java.awt.Color(0, 255, 255));
        b65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b65ActionPerformed(evt);
            }
        });

        b55.setBackground(new java.awt.Color(0, 255, 255));
        b55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b55ActionPerformed(evt);
            }
        });

        b45.setBackground(new java.awt.Color(0, 255, 255));
        b45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b45ActionPerformed(evt);
            }
        });

        b35.setBackground(new java.awt.Color(0, 255, 255));
        b35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b35ActionPerformed(evt);
            }
        });

        b25.setBackground(new java.awt.Color(0, 255, 255));
        b25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b25ActionPerformed(evt);
            }
        });

        b15.setBackground(new java.awt.Color(0, 255, 255));
        b15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b15ActionPerformed(evt);
            }
        });

        b5.setBackground(new java.awt.Color(0, 255, 255));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1.png"))); // NOI18N
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b96.setBackground(new java.awt.Color(0, 255, 255));
        b96.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b96ActionPerformed(evt);
            }
        });

        b86.setBackground(new java.awt.Color(0, 255, 255));
        b86.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b86ActionPerformed(evt);
            }
        });

        b76.setBackground(new java.awt.Color(0, 255, 255));
        b76.setIcon(new javax.swing.ImageIcon(getClass().getResource("/5.png"))); // NOI18N
        b76.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b76ActionPerformed(evt);
            }
        });

        b66.setBackground(new java.awt.Color(0, 255, 255));
        b66.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b66ActionPerformed(evt);
            }
        });

        b56.setBackground(new java.awt.Color(0, 255, 255));
        b56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b56ActionPerformed(evt);
            }
        });

        b46.setBackground(new java.awt.Color(0, 255, 255));
        b46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b46ActionPerformed(evt);
            }
        });

        b36.setBackground(new java.awt.Color(0, 255, 255));
        b36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b36ActionPerformed(evt);
            }
        });

        b26.setBackground(new java.awt.Color(0, 255, 255));
        b26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b26ActionPerformed(evt);
            }
        });

        b16.setBackground(new java.awt.Color(0, 255, 255));
        b16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b16ActionPerformed(evt);
            }
        });

        b6.setBackground(new java.awt.Color(0, 255, 255));
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b97.setBackground(new java.awt.Color(0, 255, 255));
        b97.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b97ActionPerformed(evt);
            }
        });

        b87.setBackground(new java.awt.Color(0, 255, 255));
        b87.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b87ActionPerformed(evt);
            }
        });

        b77.setBackground(new java.awt.Color(0, 255, 255));
        b77.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b77ActionPerformed(evt);
            }
        });

        b67.setBackground(new java.awt.Color(0, 255, 255));
        b67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b67ActionPerformed(evt);
            }
        });

        b57.setBackground(new java.awt.Color(0, 255, 255));
        b57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b57ActionPerformed(evt);
            }
        });

        b47.setBackground(new java.awt.Color(0, 255, 255));
        b47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b47ActionPerformed(evt);
            }
        });

        b37.setBackground(new java.awt.Color(0, 255, 255));
        b37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/2.png"))); // NOI18N
        b37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b37ActionPerformed(evt);
            }
        });

        b27.setBackground(new java.awt.Color(0, 255, 255));
        b27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/2.png"))); // NOI18N
        b27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b27ActionPerformed(evt);
            }
        });

        b17.setBackground(new java.awt.Color(0, 255, 255));
        b17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b17ActionPerformed(evt);
            }
        });

        b7.setBackground(new java.awt.Color(0, 255, 255));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b98.setBackground(new java.awt.Color(0, 255, 255));
        b98.setIcon(new javax.swing.ImageIcon(getClass().getResource("/3.png"))); // NOI18N
        b98.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b98ActionPerformed(evt);
            }
        });

        b88.setBackground(new java.awt.Color(0, 255, 255));
        b88.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b88ActionPerformed(evt);
            }
        });

        b78.setBackground(new java.awt.Color(0, 255, 255));
        b78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b78.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b78ActionPerformed(evt);
            }
        });

        b68.setBackground(new java.awt.Color(0, 255, 255));
        b68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b68ActionPerformed(evt);
            }
        });

        b58.setBackground(new java.awt.Color(0, 255, 255));
        b58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b58ActionPerformed(evt);
            }
        });

        b48.setBackground(new java.awt.Color(0, 255, 255));
        b48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b48ActionPerformed(evt);
            }
        });

        b38.setBackground(new java.awt.Color(0, 255, 255));
        b38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b38ActionPerformed(evt);
            }
        });

        b28.setBackground(new java.awt.Color(0, 255, 255));
        b28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b28ActionPerformed(evt);
            }
        });

        b18.setBackground(new java.awt.Color(0, 255, 255));
        b18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b18ActionPerformed(evt);
            }
        });

        b8.setBackground(new java.awt.Color(0, 255, 255));
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b99.setBackground(new java.awt.Color(0, 255, 255));
        b99.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b99ActionPerformed(evt);
            }
        });

        b89.setBackground(new java.awt.Color(0, 255, 255));
        b89.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b89ActionPerformed(evt);
            }
        });

        b79.setBackground(new java.awt.Color(0, 255, 255));
        b79.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b79ActionPerformed(evt);
            }
        });

        b69.setBackground(new java.awt.Color(0, 255, 255));
        b69.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b69ActionPerformed(evt);
            }
        });

        b59.setBackground(new java.awt.Color(0, 255, 255));
        b59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b59ActionPerformed(evt);
            }
        });

        b49.setBackground(new java.awt.Color(0, 255, 255));
        b49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b49ActionPerformed(evt);
            }
        });

        b39.setBackground(new java.awt.Color(0, 255, 255));
        b39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b39ActionPerformed(evt);
            }
        });

        b29.setBackground(new java.awt.Color(0, 255, 255));
        b29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b29ActionPerformed(evt);
            }
        });

        b19.setBackground(new java.awt.Color(0, 255, 255));
        b19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b19ActionPerformed(evt);
            }
        });

        b9.setBackground(new java.awt.Color(0, 255, 255));
        b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        b100.setBackground(new java.awt.Color(0, 255, 255));
        b100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b100.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b100ActionPerformed(evt);
            }
        });

        b90.setBackground(new java.awt.Color(0, 255, 255));
        b90.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b90ActionPerformed(evt);
            }
        });

        b80.setBackground(new java.awt.Color(0, 255, 255));
        b80.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b80ActionPerformed(evt);
            }
        });

        b70.setBackground(new java.awt.Color(0, 255, 255));
        b70.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b70ActionPerformed(evt);
            }
        });

        b60.setBackground(new java.awt.Color(0, 255, 255));
        b60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b60ActionPerformed(evt);
            }
        });

        b50.setBackground(new java.awt.Color(0, 255, 255));
        b50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/4.png"))); // NOI18N
        b50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b50ActionPerformed(evt);
            }
        });

        b40.setBackground(new java.awt.Color(0, 255, 255));
        b40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b40ActionPerformed(evt);
            }
        });

        b30.setBackground(new java.awt.Color(0, 255, 255));
        b30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b30ActionPerformed(evt);
            }
        });

        b20.setBackground(new java.awt.Color(0, 255, 255));
        b20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/2.png"))); // NOI18N
        b20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b20ActionPerformed(evt);
            }
        });

        b10.setBackground(new java.awt.Color(0, 255, 255));
        b10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b10ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Score:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        lScore.setBackground(new java.awt.Color(102, 102, 102));
        lScore.setFont(new java.awt.Font("Monospaced", 1, 25)); // NOI18N
        lScore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lScore.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lScore, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lScore, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(102, 102, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Time:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        lTimer.setBackground(new java.awt.Color(102, 102, 102));
        lTimer.setFont(new java.awt.Font("Monospaced", 1, 25)); // NOI18N
        lTimer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lTimer.setText("60");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lTimer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lTimer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel4.setBackground(new java.awt.Color(102, 102, 102));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Menu"));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jButton1.setBackground(new java.awt.Color(153, 153, 153));
        jButton1.setText("FORFEIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton1KeyPressed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setText("HINT(5)");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b41, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(b71, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(b81, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                                .addGap(6, 6, 6)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b12, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b22, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b32, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b42, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b52, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b62, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b72, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b82, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b23, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b33, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b43, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b53, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b63, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b73, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b83, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b13, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b14, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b24, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b34, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b44, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b54, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b64, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b74, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b84, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b15, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b25, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b35, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b45, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b55, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b65, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b85, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b75, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b16, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b26, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b36, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b46, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b56, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b66, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b76, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b86, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b17, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b27, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b37, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b47, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b57, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b67, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b77, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b87, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b18, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b28, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b38, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b48, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b58, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b68, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b78, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b88, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b19, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b29, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b39, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b49, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b59, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b69, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b79, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b89, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(b20, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b30, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b40, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b50, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b60, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b70, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b80, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(b90, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(b91, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b92, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b93, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b94, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b95, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b96, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b97, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b98, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b99, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b100, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(b13, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(b23, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(b12, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(b32, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b42, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b52, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b62, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b72, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b82, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(b33, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b30, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b40, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b50, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b60, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b70, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b80, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b90, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b19, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b29, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b39, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b49, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b59, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b69, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b79, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b89, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b18, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b28, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b38, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b48, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b58, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b68, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b78, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b88, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b17, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b27, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b37, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b47, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b57, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b67, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b77, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b87, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b16, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b26, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b36, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b46, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b56, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b66, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b76, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b86, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b15, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b25, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b35, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b45, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b55, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b65, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b75, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b85, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b11, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b21, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b31, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b41, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b51, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b61, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b71, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b81, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b14, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b24, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b34, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b44, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b43, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b54, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b53, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b64, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b63, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b74, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b73, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b83, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b84, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b100, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b99, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b98, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b97, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b96, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b95, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b94, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b93, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b92, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b91, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        // TODO add your handling code here:
        b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        
    }//GEN-LAST:event_b1ActionPerformed

    private void b41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b41ActionPerformed
        // TODO add your handling code here:
      //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
      //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
         timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
        
        
    }//GEN-LAST:event_b41ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b4ActionPerformed

    private void b23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b23ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("C:src\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
        
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b23ActionPerformed

    private void b15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b15ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b15ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b7ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        // TODO add your handling code here:
         //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b9ActionPerformed

    private void b45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b45ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b45ActionPerformed

    private void b48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b48ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b48ActionPerformed

    private void b63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b63ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b63ActionPerformed

    private void b66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b66ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b66ActionPerformed

    private void b73ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b73ActionPerformed
        // TODO add your handling code here: 
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
//<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b73ActionPerformed

    private void b78ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b78ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b78ActionPerformed

    private void b95ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b95ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b95ActionPerformed

    private void b100ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b100ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
         Icon icon = new ImageIcon("D:\\Bomb.png");
      Icon ic1 = new ImageIcon("D:\\1.png");
      Icon ic2 = new ImageIcon("D:\\2.png");
      Icon ic3 = new ImageIcon("D:\\3.png");
      Icon ic4 = new ImageIcon("D:\\4.png");
      Icon ic5 = new ImageIcon("D:\\5.png");
      Icon ic6 = new ImageIcon("D:\\6.png");
      Icon ic7 = new ImageIcon("D:\\7.png");
      Icon ic8 = new ImageIcon("D:\\8.png");
      
        b41.setIcon(icon);
        b23.setIcon(icon);
        b63.setIcon(icon);
        b73.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b95.setIcon(icon);
        b7.setIcon(icon);
        b9.setIcon(icon);
        b48.setIcon(icon);
        b66.setIcon(icon);
        b78.setIcon(icon);
        b100.setIcon(icon);
        
        b41.setBackground(null);
        b23.setBackground(null);
        b63.setBackground(null);
        b73.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null);
        b95.setBackground(null);
        b7.setBackground(null);
        b9.setBackground(null);
        b48.setBackground(null);
        b66.setBackground(null);
        b78.setBackground(null);
        b100.setBackground(null);
        
        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b20.setIcon(ic2);
        b27.setIcon(ic2);
        b34.setIcon(ic7);
        b37.setIcon(ic2);
        b50.setIcon(ic4);
        b64.setIcon(ic8);
        b76.setIcon(ic5);
        b81.setIcon(ic1);
        b91.setIcon(ic1);
        b94.setIcon(ic6);
        b98.setIcon(ic3);
         //</editor-fold>
         //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b1.setEnabled(false);
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        b11.setEnabled(false);
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b18.setEnabled(false);
        b19.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b49.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
        b65.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b76.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        b99.setEnabled(false);
        
         //</editor-fold>
          timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b100ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        // TODO add your handling code here:
        int Point = 1;
        Icon icon = new ImageIcon("D:\\1.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b3.setBackground(null);
        b3.setIcon(icon);
        b3.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        // TODO add your handling code here:
        b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b2ActionPerformed

    private void b11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b11ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b11ActionPerformed

    private void b12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b12ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b12ActionPerformed

    private void b21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b21ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b21ActionPerformed

    private void b22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b22ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b22ActionPerformed

    private void b31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b31ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b31ActionPerformed

    private void b32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b32ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b32ActionPerformed

    private void b33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b33ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b33ActionPerformed

    private void b42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b42ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b42ActionPerformed

    private void b43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b43ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b43ActionPerformed

    private void b44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b44ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b44ActionPerformed

    private void b51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b51ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b51ActionPerformed

    private void b52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b52ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b52ActionPerformed

    private void b53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b53ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b53ActionPerformed

    private void b54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b54ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b54ActionPerformed

    private void b61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b61ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b61ActionPerformed

    private void b62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b62ActionPerformed
        // TODO add your handling code here:
         b1.setEnabled(false);
        b11.setEnabled(false);
        b21.setEnabled(false);
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b31.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        b42.setEnabled(false);
        b43.setEnabled(false);
        b44.setEnabled(false);
        b51.setEnabled(false);
        b52.setEnabled(false);
        b53.setEnabled(false);
        b54.setEnabled(false);
        b61.setEnabled(false);
        b62.setEnabled(false);
    }//GEN-LAST:event_b62ActionPerformed

    private void b71ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b71ActionPerformed
        // TODO add your handling code here:
        b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b71ActionPerformed

    private void b72ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b72ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b72ActionPerformed

    private void b82ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b82ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b82ActionPerformed

    private void b92ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b92ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b92ActionPerformed

    private void b83ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b83ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b83ActionPerformed

    private void b93ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b93ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b93ActionPerformed

    private void b84ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b84ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b84ActionPerformed

    private void b74ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b74ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b74ActionPerformed

    private void b75ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b75ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b75ActionPerformed

    private void b65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b65ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b65ActionPerformed

    private void b85ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b85ActionPerformed
        // TODO add your handling code here:
         b65.setEnabled(false);
        b71.setEnabled(false);
        b72.setEnabled(false);
        b74.setEnabled(false);
        b75.setEnabled(false);
        b82.setEnabled(false);
        b83.setEnabled(false);
        b84.setEnabled(false);
        b85.setEnabled(false);
        b92.setEnabled(false);
        b93.setEnabled(false);
    }//GEN-LAST:event_b85ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        // TODO add your handling code here:
        
        int Point = 1;
        Icon icon1 = new ImageIcon("D:\\1.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b5.setBackground(null);
        b5.setIcon(icon1);
        b5.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b5ActionPerformed

    private void b27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b27ActionPerformed
        // TODO add your handling code here:
        int Point = 2;
        Icon icon = new ImageIcon("D:\\2.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b27.setBackground(null);
        b27.setIcon(icon);
        b27.setEnabled(false);
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b27ActionPerformed

    private void b20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b20ActionPerformed
        // TODO add your handling code here:
        int Point = 2;
        Icon icon = new ImageIcon("D:\\2.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b20.setBackground(null);
        b20.setIcon(icon);
        b20.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b20ActionPerformed

    private void b37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b37ActionPerformed
        // TODO add your handling code here:
        int Point = 2;
        Icon icon = new ImageIcon("D:\\2.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b37.setBackground(null);
        b37.setIcon(icon);
        b37.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b37ActionPerformed

    private void b50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b50ActionPerformed
        // TODO add your handling code here:
        int Point = 4;
        Icon icon = new ImageIcon("D:\\4.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b50.setBackground(null);
        b50.setIcon(icon);
        b50.setEnabled(false);
        if (Score>=13)
        {
        timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b50ActionPerformed

    private void b13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b13ActionPerformed
        // TODO add your handling code here:
        int Point = 3;
        Icon icon = new ImageIcon("D:\\3.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b13.setBackground(null);
        b13.setIcon(icon);
        b13.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b13ActionPerformed

    private void b64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b64ActionPerformed
        // TODO add your handling code here:
        int Point = 8;
        Icon icon = new ImageIcon("D:\\8.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b64.setBackground(null);
        b64.setIcon(icon);
        b64.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
        
    }//GEN-LAST:event_b64ActionPerformed

    private void b34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b34ActionPerformed
        // TODO add your handling code here:
        int Point = 7;
        Icon icon = new ImageIcon("D:\\7.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b34.setBackground(null);
        b34.setIcon(icon);
        b34.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b34ActionPerformed

    private void b76ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b76ActionPerformed
        // TODO add your handling code here:
        int Point = 5;
        Icon icon = new ImageIcon("D:\\5.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b76.setBackground(null);
        b76.setIcon(icon);
        b76.setEnabled(false);
        if (Score>=13)
        {
        timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b76ActionPerformed

    private void b94ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b94ActionPerformed
        // TODO add your handling code here:
       int Point = 6;
        Icon icon = new ImageIcon("D:\\6.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b94.setBackground(null);
        b94.setIcon(icon); 
        b94.setEnabled(false);
        if (Score>=13)
        {
        timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b94ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b6ActionPerformed

    private void b16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b16ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b16ActionPerformed

    private void b17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b17ActionPerformed
        // TODO add your handling code here:
        b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b17ActionPerformed

    private void b26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b26ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b26ActionPerformed

    private void b35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b35ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b35ActionPerformed

    private void b36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b36ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b36ActionPerformed

    private void b46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b46ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b46ActionPerformed

    private void b47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b47ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b47ActionPerformed

    private void b56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b56ActionPerformed
        // TODO add your handling code here:
        b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b56ActionPerformed

    private void b57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b57ActionPerformed
        // TODO add your handling code here:
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b57ActionPerformed

    private void b81ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b81ActionPerformed
        // TODO add your handling code here:
        int Point = 1;
        Icon icon = new ImageIcon("D:\\1.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b81.setText(Total);
        b81.setBackground(null);
        b81.setIcon(icon);
        b81.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b81ActionPerformed

    private void b91ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b91ActionPerformed
        // TODO add your handling code here:
        int Point = 1;
        Icon icon = new ImageIcon("D:\\1.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b91.setBackground(null);
        b91.setIcon(icon);
        b91.setEnabled(false);
        if (Score>=13)
        {
            timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b91ActionPerformed

    private void b98ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b98ActionPerformed
        // TODO add your handling code here:
        int Point = 1;
        Icon icon = new ImageIcon("D:\\3.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b98.setText(Total);
        b98.setBackground(null);
        b98.setIcon(icon);
        b98.setEnabled(false);
        if (Score>=13)
        {
        timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b98ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        timer.stop();
        int Message = JOptionPane.showConfirmDialog(null, "ARE YOU SURE YOU WANT TO FORFEIT?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);
        if (Message == JOptionPane.YES_OPTION) {
        Integer Score = Integer.parseInt(lScore.getText());
        String Total = Score.toString();
        new GameOver(Total).setVisible(true);
        dispose();
        }
        if (Message == JOptionPane.NO_OPTION)
        {
            timer.start();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton1KeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton1KeyPressed

    private void b14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b14ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b14ActionPerformed

    private void b24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b24ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b24ActionPerformed

    private void b25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b25ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b25ActionPerformed

    private void b55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b55ActionPerformed
        // TODO add your handling code here:
         b26.setEnabled(false);
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b6.setEnabled(false);
        b16.setEnabled(false);
        b17.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b47.setEnabled(false);
        b57.setEnabled(false);
    }//GEN-LAST:event_b55ActionPerformed

    private void b10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b10ActionPerformed
        // TODO add your handling code here:
        b10.setEnabled(false);
    }//GEN-LAST:event_b10ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b8ActionPerformed

    private void b18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b18ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b18ActionPerformed

    private void b19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b19ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b19ActionPerformed

    private void b28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b28ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b28ActionPerformed

    private void b29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b29ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b29ActionPerformed

    private void b30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b30ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b30ActionPerformed

    private void b38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b38ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b38ActionPerformed

    private void b39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b39ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b39ActionPerformed

    private void b40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b40ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b40ActionPerformed

    private void b49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b49ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b49ActionPerformed

    private void b58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b58ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false); 
    }//GEN-LAST:event_b58ActionPerformed

    private void b69ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b69ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b69ActionPerformed

    private void b70ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b70ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b70ActionPerformed

    private void b60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b60ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b60ActionPerformed

    private void b59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b59ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b40.setEnabled(false);
        b39.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        b60.setEnabled(false);
        b59.setEnabled(false);
    }//GEN-LAST:event_b59ActionPerformed

    private void b68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b68ActionPerformed
        // TODO add your handling code here:
        b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b68ActionPerformed

    private void b67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b67ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b67ActionPerformed

    private void b77ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b77ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b77ActionPerformed

    private void b86ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b86ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b86ActionPerformed

    private void b96ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b96ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b96ActionPerformed

    private void b97ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b97ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b97ActionPerformed

    private void b87ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b87ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b87ActionPerformed

    private void b88ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b88ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b88ActionPerformed

    private void b89ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b89ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b89ActionPerformed

    private void b99ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b99ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b99ActionPerformed

    private void b90ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b90ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b90ActionPerformed

    private void b80ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b80ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b80ActionPerformed

    private void b79ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b79ActionPerformed
        // TODO add your handling code here:
         b99.setEnabled(false);
        b97.setEnabled(false);
        b96.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b80.setEnabled(false);
        b79.setEnabled(false);
        b77.setEnabled(false);
        b67.setEnabled(false);
        b68.setEnabled(false);
    }//GEN-LAST:event_b79ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Integer a = Integer.parseInt(lScore.getText());
        Integer b= a-5;
        String c = b.toString();
        
        if (a<5)
        {
            JOptionPane.showMessageDialog(rootPane, "Sorry, but you don't have enough points.", "INFORMATION", 1);
        }
        else
        if(isFirstClick == 0)
        {
            lScore.setText(c);
            jButton2.setEnabled(false);
            b1.setEnabled(false);
            b11.setEnabled(false);
            b21.setEnabled(false);
            b22.setEnabled(false);
            b12.setEnabled(false);
            b2.setEnabled(false);
            b31.setEnabled(false);
            b32.setEnabled(false);
            b33.setEnabled(false);
            b42.setEnabled(false);
            b43.setEnabled(false);
            b44.setEnabled(false);
            b51.setEnabled(false);
            b52.setEnabled(false);
            b53.setEnabled(false);
            b54.setEnabled(false);
            b61.setEnabled(false);
            b62.setEnabled(false);
            isFirstClick = 1;
        
        
        }
        else if(isFirstClick == 1)
        {
        lScore.setText(c);
        b8.setEnabled(false);
        b18.setEnabled(false);
        b28.setEnabled(false);
        b29.setEnabled(false);
        b30.setEnabled(false);
        b38.setEnabled(false);
        b39.setEnabled(false);
        b40.setEnabled(false);
        b49.setEnabled(false);
        b58.setEnabled(false);
        b59.setEnabled(false);
        b60.setEnabled(false);
        b68.setEnabled(false);
        b69.setEnabled(false);
        b70.setEnabled(false);
        isFirstClick = 2;
        }
        else if(isFirstClick == 2)
        {
        lScore.setText(c);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b26.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b47.setEnabled(false);
        b55.setEnabled(false);
        b56.setEnabled(false);
        b57.setEnabled(false);
        isFirstClick = 3;
        }
        else if(isFirstClick == 3)
        {
        b67.setEnabled(false);
        b68.setEnabled(false);
        b77.setEnabled(false);
        b79.setEnabled(false);
        b80.setEnabled(false);
        b86.setEnabled(false);
        b87.setEnabled(false);
        b88.setEnabled(false);
        b89.setEnabled(false);
        b90.setEnabled(false);
        b99.setEnabled(false);
        b96.setEnabled(false);
        b97.setEnabled(false);
        isFirstClick = 4;
        }
        else if(isFirstClick == 4)
        {
        lScore.setText(c);
            b71.setEnabled(false);
            b72.setEnabled(false);
            b82.setEnabled(false);
            b83.setEnabled(false);
            b84.setEnabled(false);
            b85.setEnabled(false);
            b92.setEnabled(false);
            b93.setEnabled(false);
            b74.setEnabled(false);
            b75.setEnabled(false);
            b65.setEnabled(false);
            isFirstClick = 0;
        }
        
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
        
         
    }//GEN-LAST:event_jButton2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Normal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Normal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Normal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Normal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Normal().setVisible(true);
            }
        });
    }
 //<editor-fold defaultstate="collapsed" desc=" Variables declaration - do not modify) ">
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b10;
    private javax.swing.JButton b100;
    private javax.swing.JButton b11;
    private javax.swing.JButton b12;
    private javax.swing.JButton b13;
    private javax.swing.JButton b14;
    private javax.swing.JButton b15;
    private javax.swing.JButton b16;
    private javax.swing.JButton b17;
    private javax.swing.JButton b18;
    private javax.swing.JButton b19;
    private javax.swing.JButton b2;
    private javax.swing.JButton b20;
    private javax.swing.JButton b21;
    private javax.swing.JButton b22;
    private javax.swing.JButton b23;
    private javax.swing.JButton b24;
    private javax.swing.JButton b25;
    private javax.swing.JButton b26;
    private javax.swing.JButton b27;
    private javax.swing.JButton b28;
    private javax.swing.JButton b29;
    private javax.swing.JButton b3;
    private javax.swing.JButton b30;
    private javax.swing.JButton b31;
    private javax.swing.JButton b32;
    private javax.swing.JButton b33;
    private javax.swing.JButton b34;
    private javax.swing.JButton b35;
    private javax.swing.JButton b36;
    private javax.swing.JButton b37;
    private javax.swing.JButton b38;
    private javax.swing.JButton b39;
    private javax.swing.JButton b4;
    private javax.swing.JButton b40;
    private javax.swing.JButton b41;
    private javax.swing.JButton b42;
    private javax.swing.JButton b43;
    private javax.swing.JButton b44;
    private javax.swing.JButton b45;
    private javax.swing.JButton b46;
    private javax.swing.JButton b47;
    private javax.swing.JButton b48;
    private javax.swing.JButton b49;
    private javax.swing.JButton b5;
    private javax.swing.JButton b50;
    private javax.swing.JButton b51;
    private javax.swing.JButton b52;
    private javax.swing.JButton b53;
    private javax.swing.JButton b54;
    private javax.swing.JButton b55;
    private javax.swing.JButton b56;
    private javax.swing.JButton b57;
    private javax.swing.JButton b58;
    private javax.swing.JButton b59;
    private javax.swing.JButton b6;
    private javax.swing.JButton b60;
    private javax.swing.JButton b61;
    private javax.swing.JButton b62;
    private javax.swing.JButton b63;
    private javax.swing.JButton b64;
    private javax.swing.JButton b65;
    private javax.swing.JButton b66;
    private javax.swing.JButton b67;
    private javax.swing.JButton b68;
    private javax.swing.JButton b69;
    private javax.swing.JButton b7;
    private javax.swing.JButton b70;
    private javax.swing.JButton b71;
    private javax.swing.JButton b72;
    private javax.swing.JButton b73;
    private javax.swing.JButton b74;
    private javax.swing.JButton b75;
    private javax.swing.JButton b76;
    private javax.swing.JButton b77;
    private javax.swing.JButton b78;
    private javax.swing.JButton b79;
    private javax.swing.JButton b8;
    private javax.swing.JButton b80;
    private javax.swing.JButton b81;
    private javax.swing.JButton b82;
    private javax.swing.JButton b83;
    private javax.swing.JButton b84;
    private javax.swing.JButton b85;
    private javax.swing.JButton b86;
    private javax.swing.JButton b87;
    private javax.swing.JButton b88;
    private javax.swing.JButton b89;
    private javax.swing.JButton b9;
    private javax.swing.JButton b90;
    private javax.swing.JButton b91;
    private javax.swing.JButton b92;
    private javax.swing.JButton b93;
    private javax.swing.JButton b94;
    private javax.swing.JButton b95;
    private javax.swing.JButton b96;
    private javax.swing.JButton b97;
    private javax.swing.JButton b98;
    private javax.swing.JButton b99;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lScore;
    private javax.swing.JLabel lTimer;
    // End of variables declaration//GEN-END:variables
//</editor-fold>
}
