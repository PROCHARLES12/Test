
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer; 

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Charles
 */
public class Easy extends javax.swing.JFrame {
Timer timer;
int sec = 60;
int speed =1000;
    /**
     * Creates new form NewJFrame
     */
    public Easy() {
        initComponents();
        
    timer = new Timer(speed,new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                 if (sec<12)
                            {
                                lTimer.setForeground(Color.red);
                            }
                 if (sec<13)
                           {
                     try
                        {
                         Clip clip = AudioSystem.getClip();
                         clip.open(AudioSystem.getAudioInputStream(new File("D:\\timer.wav")));
                         clip.start();
                         }
                        catch (Exception exc)
                        {
                            exc.printStackTrace(System.out);
                        }
                           }
    
                 
                 
                 
                if (sec<1)
                {
                
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b7.setBackground(null);
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8); 
           b7.setIcon(icon);    
        //</editor-fold>

       
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
                      timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Times Up!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
                      sec = 0;
                      timer.stop();
                }
                else
                {
                    sec--;
                    String str2 = Integer.toString(sec);
                    lTimer.setText(str2);
                }
                
            }
        });
        timer.start();
         //<editor-fold defaultstate="collapsed" desc=" Icons ">
        b23.setIcon(null);
        b15.setIcon(null);
        b45.setIcon(null);
        b7.setIcon(null);
        b9.setIcon(null);
        
        
        b3.setIcon(null);
        b5.setIcon(null);
        b13.setIcon(null);
        b34.setIcon(null);
        b17.setIcon(null);
        b42.setIcon(null);
        b52.setIcon(null);
        b18.setIcon(null);
        b56.setIcon(null);
        b26.setIcon(null);
         //</editor-fold>
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        b52 = new javax.swing.JButton();
        b53 = new javax.swing.JButton();
        b54 = new javax.swing.JButton();
        b55 = new javax.swing.JButton();
        b56 = new javax.swing.JButton();
        b46 = new javax.swing.JButton();
        b36 = new javax.swing.JButton();
        b26 = new javax.swing.JButton();
        b16 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b12 = new javax.swing.JButton();
        b22 = new javax.swing.JButton();
        b32 = new javax.swing.JButton();
        b42 = new javax.swing.JButton();
        b43 = new javax.swing.JButton();
        b33 = new javax.swing.JButton();
        b23 = new javax.swing.JButton();
        b13 = new javax.swing.JButton();
        b14 = new javax.swing.JButton();
        b44 = new javax.swing.JButton();
        b35 = new javax.swing.JButton();
        b24 = new javax.swing.JButton();
        b25 = new javax.swing.JButton();
        b34 = new javax.swing.JButton();
        b45 = new javax.swing.JButton();
        b15 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lScore = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lTimer = new javax.swing.JLabel();
        b7 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        b10 = new javax.swing.JButton();
        b17 = new javax.swing.JButton();
        b18 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        b52.setBackground(new java.awt.Color(0, 255, 255));
        b52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b52ActionPerformed(evt);
            }
        });

        b53.setBackground(new java.awt.Color(0, 255, 255));
        b53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b53ActionPerformed(evt);
            }
        });

        b54.setBackground(new java.awt.Color(0, 255, 255));
        b54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b54ActionPerformed(evt);
            }
        });

        b55.setBackground(new java.awt.Color(0, 255, 255));
        b55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b55ActionPerformed(evt);
            }
        });

        b56.setBackground(new java.awt.Color(0, 255, 255));
        b56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/3.png"))); // NOI18N
        b56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b56ActionPerformed(evt);
            }
        });

        b46.setBackground(new java.awt.Color(0, 255, 255));
        b46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b46ActionPerformed(evt);
            }
        });

        b36.setBackground(new java.awt.Color(0, 255, 255));
        b36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b36ActionPerformed(evt);
            }
        });

        b26.setBackground(new java.awt.Color(0, 255, 255));
        b26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/5.png"))); // NOI18N
        b26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b26ActionPerformed(evt);
            }
        });

        b16.setBackground(new java.awt.Color(0, 255, 255));
        b16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b16ActionPerformed(evt);
            }
        });

        b6.setBackground(new java.awt.Color(0, 255, 255));
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b5.setBackground(new java.awt.Color(0, 255, 255));
        b5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/2.png"))); // NOI18N
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b4.setBackground(new java.awt.Color(0, 255, 255));
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b3.setBackground(new java.awt.Color(0, 255, 255));
        b3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/1.png"))); // NOI18N
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b2.setBackground(new java.awt.Color(0, 255, 255));
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b12.setBackground(new java.awt.Color(0, 255, 255));
        b12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b12ActionPerformed(evt);
            }
        });

        b22.setBackground(new java.awt.Color(0, 255, 255));
        b22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b22ActionPerformed(evt);
            }
        });

        b32.setBackground(new java.awt.Color(0, 255, 255));
        b32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b32ActionPerformed(evt);
            }
        });

        b42.setBackground(new java.awt.Color(0, 255, 255));
        b42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b42ActionPerformed(evt);
            }
        });

        b43.setBackground(new java.awt.Color(0, 255, 255));
        b43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b43ActionPerformed(evt);
            }
        });

        b33.setBackground(new java.awt.Color(0, 255, 255));
        b33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b33ActionPerformed(evt);
            }
        });

        b23.setBackground(new java.awt.Color(0, 255, 255));
        b23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b23ActionPerformed(evt);
            }
        });

        b13.setBackground(new java.awt.Color(0, 255, 255));
        b13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/6.png"))); // NOI18N
        b13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b13ActionPerformed(evt);
            }
        });

        b14.setBackground(new java.awt.Color(0, 255, 255));
        b14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b14ActionPerformed(evt);
            }
        });

        b44.setBackground(new java.awt.Color(0, 255, 255));
        b44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b44ActionPerformed(evt);
            }
        });

        b35.setBackground(new java.awt.Color(0, 255, 255));
        b35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b35ActionPerformed(evt);
            }
        });

        b24.setBackground(new java.awt.Color(0, 255, 255));
        b24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b24ActionPerformed(evt);
            }
        });

        b25.setBackground(new java.awt.Color(0, 255, 255));
        b25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b25ActionPerformed(evt);
            }
        });

        b34.setBackground(new java.awt.Color(0, 255, 255));
        b34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/7.png"))); // NOI18N
        b34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b34ActionPerformed(evt);
            }
        });

        b45.setBackground(new java.awt.Color(0, 255, 255));
        b45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b45ActionPerformed(evt);
            }
        });

        b15.setBackground(new java.awt.Color(0, 255, 255));
        b15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b15ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Score:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        lScore.setBackground(new java.awt.Color(102, 102, 102));
        lScore.setFont(new java.awt.Font("Monospaced", 1, 25)); // NOI18N
        lScore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lScore.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lScore, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lScore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Time:", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        lTimer.setBackground(new java.awt.Color(102, 102, 102));
        lTimer.setFont(new java.awt.Font("Monospaced", 1, 25)); // NOI18N
        lTimer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lTimer.setText("60");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lTimer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lTimer, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
        );

        b7.setBackground(new java.awt.Color(0, 255, 255));
        b7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b8.setBackground(new java.awt.Color(0, 255, 255));
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b9.setBackground(new java.awt.Color(0, 255, 255));
        b9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/4.png"))); // NOI18N
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        b10.setBackground(new java.awt.Color(0, 255, 255));
        b10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b10ActionPerformed(evt);
            }
        });

        b17.setBackground(new java.awt.Color(0, 255, 255));
        b17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Bomb.png"))); // NOI18N
        b17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b17ActionPerformed(evt);
            }
        });

        b18.setBackground(new java.awt.Color(0, 255, 255));
        b18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/9.png"))); // NOI18N
        b18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b18ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(b9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b18, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b12, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b22, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b32, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b42, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b52, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b23, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b33, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b43, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b53, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b13, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(b14, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b24, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b34, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b44, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b54, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(b15, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b25, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b35, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b45, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b55, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(b16, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b26, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b36, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b46, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b56, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(b13, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(b23, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(b12, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(b22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(b32, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(b42, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(b17, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(b52, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(b18, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(b33, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b16, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b26, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b36, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b46, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b56, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b15, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b25, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b35, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b45, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b55, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(b14, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b24, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(b34, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b44, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b43, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b54, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b53, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void b52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b52ActionPerformed
       // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
        
        
    }//GEN-LAST:event_b52ActionPerformed

    private void b53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b53ActionPerformed
        // TODO add your handling code here:
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b53ActionPerformed

    private void b54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b54ActionPerformed
        // TODO add your handling code here:
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b54ActionPerformed

    private void b55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b55ActionPerformed
        // TODO add your handling code here:
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b55ActionPerformed

    private void b56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b56ActionPerformed
        // TODO add your handling code here:

        int Point = 3;
        Icon icon1 = new ImageIcon("D:\\3.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b56.setEnabled(false);
        b56.setBackground(null);
        b56.setIcon(icon1);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
        
    }//GEN-LAST:event_b56ActionPerformed

    private void b46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b46ActionPerformed
        // TODO add your handling code here:
       b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b46ActionPerformed

    private void b36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b36ActionPerformed
        // TODO add your handling code here:
       b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b36ActionPerformed

    private void b26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b26ActionPerformed
        // TODO add your handling code here:

        int Point = 5;
        Icon icon1 = new ImageIcon("D:\\5.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b26.setBackground(null);
        b26.setIcon(icon1);
        b26.setEnabled(false);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }        
    }//GEN-LAST:event_b26ActionPerformed

    private void b16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b16ActionPerformed
        // TODO add your handling code here:
        b16.setEnabled(false);
        b6.setEnabled(false);
    }//GEN-LAST:event_b16ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        // TODO add your handling code here:
        b16.setEnabled(false);
        b6.setEnabled(false);
        
        
    }//GEN-LAST:event_b6ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        // TODO add your handling code here:

        int Point = 2;
        Icon icon1 = new ImageIcon("D:\\2.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b5.setBackground(null);
        b5.setIcon(icon1);
        b5.setEnabled(false);
        timer.start();
        if (Score>=13)
        {
       int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b5ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        // TODO add your handling code here:
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b4ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        // TODO add your handling code here:
        int Point = 1;
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        Icon icon = new ImageIcon("D:\\1.png");
        lScore.setText(Total);
        b3.setBackground(null);
        b3.setIcon(icon);
        b3.setEnabled(false);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        // TODO add your handling code here:
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b2ActionPerformed

    private void b12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b12ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b12ActionPerformed

    private void b22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b22ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b22ActionPerformed

    private void b32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b32ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b32ActionPerformed

    private void b42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b42ActionPerformed
        // TODO add your handling code here:
        
        
        
       // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
        
        
    }//GEN-LAST:event_b42ActionPerformed

    private void b43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b43ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b18.setEnabled(false);
        
    }//GEN-LAST:event_b43ActionPerformed

    private void b33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b33ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b33ActionPerformed

    private void b23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b23ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b23ActionPerformed

    private void b13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b13ActionPerformed
        // TODO add your handling code here:
        int Point = 6;
        Icon icon = new ImageIcon("D:\\6.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b13.setBackground(null);
        b13.setIcon(icon);
        b13.setEnabled(false);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b13ActionPerformed

    private void b14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b14ActionPerformed
        // TODO add your handling code here:
       b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b14ActionPerformed

    private void b44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b44ActionPerformed
        // TODO add your handling code here:
        
        
        
        b22.setEnabled(false);
        b12.setEnabled(false);
        b2.setEnabled(false);
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        
        
    }//GEN-LAST:event_b44ActionPerformed

    private void b35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b35ActionPerformed
        // TODO add your handling code here:
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b35ActionPerformed

    private void b24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b24ActionPerformed
        // TODO add your handling code here:
        b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b24ActionPerformed

    private void b25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b25ActionPerformed
        // TODO add your handling code here:
       b4.setEnabled(false);
        b14.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        b46.setEnabled(false);
        b55.setEnabled(false);
        
        
    }//GEN-LAST:event_b25ActionPerformed

    private void b34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b34ActionPerformed
        // TODO add your handling code here:

        int Point = 7;
        Icon icon1 = new ImageIcon("D:\\7.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b34.setEnabled(false);
        b34.setBackground(null);
        b34.setIcon(icon1);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
           new Congratulations(Total).setVisible(true);
            hide();
        }
        }
        
    }//GEN-LAST:event_b34ActionPerformed

    private void b45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b45ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b45ActionPerformed

    private void b15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b15ActionPerformed
       // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b15ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
         // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);
        b7.setBackground(null);
        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>
b7.setBackground(null);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
        
    }//GEN-LAST:event_b7ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        // TODO add your handling code here:
        b8.setEnabled(false);
    }//GEN-LAST:event_b8ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        // TODO add your handling code here:
        int Point = 4;
        Icon icon = new ImageIcon("D:\\4.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b9.setBackground(null);
        b9.setIcon(icon);
        b9.setEnabled(false);
        timer.start();
        if (Score>=15)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b9ActionPerformed

    private void b10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b10ActionPerformed
        // TODO add your handling code here:
        b10.setEnabled(false);
    }//GEN-LAST:event_b10ActionPerformed

    private void b17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b17ActionPerformed
        // TODO add your handling code here:
        //<editor-fold defaultstate="collapsed" desc=" Icons ">
        Icon icon = new ImageIcon("C:src\\Bomb.png");
        Icon ic1 = new ImageIcon("D:\\1.png");
        Icon ic2 = new ImageIcon("D:\\2.png");
        Icon ic3 = new ImageIcon("D:\\3.png");
        Icon ic4 = new ImageIcon("D:\\4.png");
        Icon ic5 = new ImageIcon("D:\\5.png");
        Icon ic6 = new ImageIcon("D:\\6.png");
        Icon ic7 = new ImageIcon("D:\\7.png");
        Icon ic8 = new ImageIcon("D:\\8.png");

        b23.setIcon(icon);
        b15.setIcon(icon);
        b45.setIcon(icon);
        b7.setIcon(icon);

        b23.setBackground(null);
        b26.setBackground(null);
        b56.setBackground(null);
        b15.setBackground(null);
        b45.setBackground(null); 
        b17.setBackground(null); 
          b42.setBackground(null); 
           b52.setBackground(null); 
            b9.setBackground(null); 
            b18.setBackground(null); 
        b26.setBackground(null); 
        b56.setBackground(null); 
        b26.setIcon(ic5);
        b56.setIcon(ic3);

        b3.setIcon(ic1);
        b5.setIcon(ic1);
        b13.setIcon(ic3);
        b34.setIcon(ic7);
         b17.setIcon(icon);
          b42.setIcon(icon);
           b52.setIcon(icon);
           b9.setIcon(ic4);
           b18.setIcon(ic8);
        //</editor-fold>

        b7.setIcon(icon);
        //<editor-fold defaultstate="collapsed" desc=" No Points Buttons ">
        b2.setEnabled(false);
        b4.setEnabled(false);
        b6.setEnabled(false);
        b8.setEnabled(false);
        b10.setEnabled(false);
        
        
        b12.setEnabled(false);
        b14.setEnabled(false);
        b16.setEnabled(false);
        
        
        
        
        b22.setEnabled(false);
        b24.setEnabled(false);
        b25.setEnabled(false);
        
        
        
        
        b32.setEnabled(false);
        b33.setEnabled(false);
        b35.setEnabled(false);
        b36.setEnabled(false);
        
        
        
        
        b43.setEnabled(false);
        b44.setEnabled(false);
        b46.setEnabled(false);
        
        
        
        
        b53.setEnabled(false);
        b54.setEnabled(false);
        b55.setEnabled(false);

        //</editor-fold>
        timer.stop();JOptionPane.showMessageDialog(rootPane, "Game Over", "Wrong Move!", 0);MainMenu mm = new MainMenu();mm.setVisible(true);dispose();
    }//GEN-LAST:event_b17ActionPerformed

    private void b18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b18ActionPerformed
        // TODO add your handling code here:
        int Point = 8;
        Icon icon = new ImageIcon("D:\\8.png");
        Integer Score = Integer.parseInt(lScore.getText());
        Integer Var1 = Score + Point;
        String Total = Var1.toString();
        lScore.setText(Total);
        b18.setBackground(null);
        b18.setIcon(icon);
        b18.setEnabled(false);
        timer.start();
        if (Score>=13)
        {
        int Message = JOptionPane.showConfirmDialog(null, "YOU HAVE REACHED THE PASSING SCORE \n DO YOU WANT TO CONTINUE?", "CONFIRMATION", JOptionPane.YES_NO_OPTION);  
        if (Message == JOptionPane.YES_OPTION) {
            timer.start();
        }
        else if (Message == JOptionPane.NO_OPTION){
            timer.stop();
            new Congratulations(Total).setVisible(true);
            hide();
        }
        }
    }//GEN-LAST:event_b18ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Easy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Easy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Easy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Easy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Easy().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b10;
    private javax.swing.JButton b12;
    private javax.swing.JButton b13;
    private javax.swing.JButton b14;
    private javax.swing.JButton b15;
    private javax.swing.JButton b16;
    private javax.swing.JButton b17;
    private javax.swing.JButton b18;
    private javax.swing.JButton b2;
    private javax.swing.JButton b22;
    private javax.swing.JButton b23;
    private javax.swing.JButton b24;
    private javax.swing.JButton b25;
    private javax.swing.JButton b26;
    private javax.swing.JButton b3;
    private javax.swing.JButton b32;
    private javax.swing.JButton b33;
    private javax.swing.JButton b34;
    private javax.swing.JButton b35;
    private javax.swing.JButton b36;
    private javax.swing.JButton b4;
    private javax.swing.JButton b42;
    private javax.swing.JButton b43;
    private javax.swing.JButton b44;
    private javax.swing.JButton b45;
    private javax.swing.JButton b46;
    private javax.swing.JButton b5;
    private javax.swing.JButton b52;
    private javax.swing.JButton b53;
    private javax.swing.JButton b54;
    private javax.swing.JButton b55;
    private javax.swing.JButton b56;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lScore;
    private javax.swing.JLabel lTimer;
    // End of variables declaration//GEN-END:variables
}
